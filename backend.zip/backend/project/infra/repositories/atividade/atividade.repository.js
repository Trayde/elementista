
"use strict";

const { PrismaClient } = require('@prisma/client');

module.exports = class AtividadeRepository {

  constructor() {
    this.prisma = new PrismaClient();
  }


  async gravaAtividade() {
    const retorno = await this.prisma.atividades.findMany()

    return retorno
  }


}

