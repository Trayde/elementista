const express = require('express');
const router = express.Router();
const ctrl = require("../../controllers/atividades/atividades.controller"); 
const path = require('path'); // Importação da biblioteca path
const multer = require('multer');
const uploadsDir = path.join('C:', 'xampp', 'htdocs', 'visitas');
const upload = multer({ dest: uploadsDir });

const _ctrl = new ctrl();

console.log("visitas");
// Define a rota raiz
// router.get('/', (req, res) => _ctrl.usuario(req, res));

// Defina outras rotas conforme necessário
router.get('/usuarios/:token', (req, res) => _ctrl.usuario(req, res));
router.get('/avatar',  (req, res) => _ctrl.avatar(req, res));

router.get('/obterVisitas',  (req, res) => _ctrl.obterVisitas(req, res));

router.post('/imagensvisitas', upload.single('file'), (req, res) => _ctrl.imagens(req, res));
router.post('/gravaAtividade', (req, res) => _ctrl.gravaAtividade(req, res));



module.exports = router;
