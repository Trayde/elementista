const express = require('express');
const multer = require('multer');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const upload = multer({ dest: 'uploads/' });
const { Container } = require("../../../infra/middlewares/dependency.injection");

module.exports = class UsuariosController {

    constructor() {
        this.atividadeServices = Container().resolve("atividadeServices");

    }


    async gravaAtividade(req, res) {
        try {

            const response = await this.atividadeServices.gravaAtividade(req.body);

            return res.status(200).send(response);
        } catch (error) {
            return res.status(500).send(error);
        }
    }

    async obterVisitas(req, res) {
        try {
            const response = await this.visitasServices.obterVisitas();
            return res.status(200).send(response);
        } catch (error) {
            return res.status(500).send(error);
        }
    }

    async imagens(req, res) {

        try {
            const { chave, fileName, tag } = req.body;
            const file = req.file;


            if (!file) {
                return res.status(400).send("No file uploaded.");
            }

            // Salvar metadados da imagem no banco de dados
            const savedImage = await prisma.image.create({
                data: {
                    chave: chave,
                    fileName: fileName,
                    filePath: file.filename, // Caminho onde a imagem foi salva
                    tag: tag
                },
            });

            return res.status(200).json(savedImage);
        } catch (error) {
            console.error(error);
            return res.status(400).send(error);
        }
    }



}



