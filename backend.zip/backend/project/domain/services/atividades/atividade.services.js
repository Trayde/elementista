"use strict";
const { Container } = require("../../../infra/middlewares/dependency.injection");

module.exports = class AtividadeServices {
    constructor() {
        const container = Container();
        this.atividadeRepository = container.resolve("atividadeRepository");
        
        
    }

    async gravaAtividade () {
        console.log("service visitas backend");
        return await this.atividadeRepository.gravaAtividade();
    }



}