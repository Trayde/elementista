const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path'); // Importação da biblioteca path
const usuarios = require('./project/web/routers/usuarios.router');
const imagens = require('./project/web/routers/usuarios.router');
const atividades = require('./project/web/routers/atividades/atividades.router');

const port = 5000;

app.use(bodyParser.json({ limit: '2gb' })); 
app.use(bodyParser.urlencoded({ extended: true }));
const uploadsDir = path.join('C:', 'xampp', 'htdocs', 'uploads');
const upload = multer({ dest: uploadsDir });

// Middleware para servir arquivos estáticos do diretório 'uploads'
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(cors()); // Permite requisições de todos os domínios
app.use('/', usuarios); 
app.use('/imagens', imagens); // Associa o middleware 'usuarios' apenas a requisições para '/usuarios'
app.use('/imagensvisitas' , atividades);
app.use('/atividades' , atividades);
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
